import os
import sys
import re
import glob
import pandas as pd
import numpy as np

# 初始化变量
time_tt = 0
time_points = []
target_dir = "./gensva/inter_hbi/"
core_mod = "core_gen_block"

time_stats = {
    'data': {'local': 0, 'global': 0},
    'struct': {
        'temporal': {'local': 0, 'global': 0},
        'spatial':  0
    }
}

cnt_stats = {
    'data': {'local': 0, 'global': 0},
    'struct': {
        'temporal': {'local': 0, 'global': 0},
        'spatial':  0
    }
}

# 检查目标目录和元数据文件
if not os.path.isdir(target_dir):
    sys.exit("no directory %s" % target_dir)
if not os.path.exists(target_dir + "hbi_meta.txt"):
    sys.exit("no hbi_meta.txt %s" % (target_dir + "hbi_meta.txt"))

# 读取元数据文件
meta_dt = pd.read_csv(target_dir + "hbi_meta.txt")
meta_dtypes = {
    "file_#": 'int64',
    "hbi_type": "int64",
    "samecore": "int64",
    "i0_type": "int64",
    "i1_type": "int64",
    "i0_loc": "object",
    "i1_loc": "object",
    "relevant_file_#": "int64",
    "Result": 'str'
}

# 自动生成 sby_inter_hbi.sby 文件的函数
def generate_sby_file():
    sby_dir = "revised_script"
    sby_path = os.path.join(sby_dir, "sby_inter_hbi.sby")
    
    # 检查文件是否存在，如果不存在则生成
    if not os.path.exists(sby_path):
        print(f"'{sby_path}' 不存在，开始生成该文件...")
        os.makedirs(sby_dir, exist_ok=True)
        
        sby_content = """
[options]
mode bmc
depth 100

[engines]
smtbmc yices

[script]
read -formal {sva_file}
prep -top vscale_sim_top_dup

clock clk
reset reset

[files]
./src/main/verilog/vscale_sim_top_unmod.v
{sva_file}
"""
        with open(sby_path, "w") as sby_file:
            sby_file.write(sby_content)
        print(f"生成 {sby_path} 成功！")
    else:
        print(f"'{sby_path}' 文件已存在，无需生成。")
    return sby_path

# 更新解析函数
def parse_update(meta, res, allpair=False, allinstn=False):
    global time_tt
    global time_points
    global time_stats
    global cnt_stats

    idx = re.findall("[0-9]+", itm)[0]

    if not os.path.exists(meta) or not os.path.exists(res):
        print("no " + meta + " or " + res)
        sys.exit(1)

    dt = pd.read_csv(res)
    row_ = meta_dt.loc[meta_dt['file_#'] == int(idx)]
    isdata = sum(row_['hbi_type'] == 2)
    isspatial = sum(row_['hbi_type'] == 0)
    islocal = sum(row_['i0_loc'].str.contains(core_mod) & row_['i1_loc'].str.contains(core_mod))

    tt_ = sum(dt['Time'].apply(lambda x: float(re.sub('[^0-9.]', '', x))))
    if (not allpair) and (not allinstn):
        time_tt += tt_
        time_points.append(tt_)
        print(res, "total time ", tt_)

    res_ = None
    for x, y in dt.iterrows():
        if 'assert' in y['Name'] and not ('precondition' in y['Name']):
            res_ = y['Result']

    if allpair or allinstn:
        return res_

    if isdata:
        if islocal:
            cnt_stats['data']['local'] += 1
            time_stats['data']['local'] += tt_
        else:
            cnt_stats['data']['global'] += 1
            time_stats['data']['global'] += tt_
    else:
        if isspatial:
            cnt_stats['struct']['spatial'] += 1
            time_stats['struct']['spatial'] += tt_
        else:
            if islocal:
                cnt_stats['struct']['temporal']['local'] += 1
                time_stats['struct']['temporal']['local'] += tt_
            else:
                cnt_stats['struct']['temporal']['global'] += 1
                time_stats['struct']['temporal']['global'] += tt_

    return res_

# 初始化计数器
count_ = {}
count_data = {}
count_fileseq = {}
count_data_fileseq = {}

for x, y in meta_dt.iterrows():
    if y['hbi_type'] == 2:  # 数据流关系
        k1 = (y['i0_type'], y['hbi_type'], y['samecore'], y['relevant_file_#'])
        if k1 not in count_data:
            count_data_fileseq[k1] = y['file_#']
        count_data[k1] = count_data.get(k1, 0) + 1
    if y['relevant_file_#'] == -1 and y['hbi_type'] != 2:  # 结构化时空关系
        pair = (y['i0_loc'], y['i1_loc'], y['hbi_type'], y['samecore'], y['relevant_file_#'])
        if pair not in count_:
            count_fileseq[pair] = y['file_#']
        count_[pair] = count_.get(pair, 0) + 1

print(count_)
INSTN = 2
PAIR_CNT = INSTN * INSTN  # 指令类型平方
print("cnt of instruction: %d " % PAIR_CNT)
fin = {}

# 处理结构化数据流分析
for k, v in count_.items():
    if v == PAIR_CNT:
        fin[k] = False
        file_ = count_fileseq[k]
        org_f = target_dir + str(file_) + ".sv"
        if not os.path.isfile(org_f):
            print("fail")
            continue
        mod_f = target_dir + str(file_) + "_reduce4.sv"
        with open(mod_f, "w") as tmpf:
            with open(org_f, "r") as f:
                for line in f:
                    if "//input_instructions" in line:
                        tmpf.write("//" + line)
                    elif "all_instructions" in line:
                        tmpf.write(line[2:])
                    else:
                        tmpf.write(line)
        print(mod_f)

print(count_data)
fin_data = {}

# 处理数据流分析
for k, v in count_data.items():
    if v == INSTN:
        print("data", k, v)

        fin_data[k] = False
        file_ = count_data_fileseq[k]
        org_f = target_dir + str(file_) + ".sv"
        if not os.path.isfile(org_f):
            print("fail")
            continue
        mod_f = target_dir + str(file_) + "_reduce2.sv"
        with open(mod_f, "w") as tmpf:
            tmpcnt = 0
            with open(org_f, "r") as f:
                for line in f:
                    if "//input_instructions" in line:
                        tmpcnt += 1
                        if tmpcnt == 2:
                            tmpf.write("//" + line)
                        else:
                            tmpf.write(line)
                    elif "all_instructions" in line:
                        tmpf.write(line[2:])
                    else:
                        tmpf.write(line)
        print(mod_f)

# 更新验证结果
update_map_f = pd.DataFrame()
for x, y in meta_dt.iterrows():
    itm = target_dir + str(y['file_#']) + ".sv"
    if 'result' in itm:
        continue
    idx = re.findall("[0-9]+", itm)[0]
    sva_file = itm
    if not os.path.exists(sva_file):
        print("sva don't exists %s" % sva_file)
        continue

    result = "hbi_" + str(idx)
    rundir = itm.split(".sv")[0]
    result_ = rundir + "_dir/" + result + ".csv"
    key = (y['i0_loc'], y['i1_loc'], y['hbi_type'], y['samecore'], y['relevant_file_#'])

    # 使用自动生成的sby进行分析，替换原来的jg
    if count_.get(key, -1) == PAIR_CNT:
        result = "hbi_" + str(count_fileseq[key])
        rundir = target_dir + str(count_fileseq[key]) + "_reduce4"
        result_ = rundir + "_dir/" + result + ".csv"
        sva_file = target_dir + str(count_fileseq[key]) + "_reduce4.sv"

    k1 = (y['i0_type'], y['hbi_type'], y['samecore'], y['relevant_file_#'])
    if y['hbi_type'] == 2 and count_data.get(k1, -1) == INSTN:
        result = "hbi_" + str(count_data_fileseq[k1])
        rundir = target_dir + str(count_data_fileseq[k1]) + "_reduce2"
        result_ = rundir + "_dir/" + result + ".csv"
        sva_file = target_dir + str(count_data_fileseq[k1]) + "_reduce2.sv"
        print("sva file %s", sva_file)

    if os.path.exists(result_):
        print("pass")
    else:
        # 使用生成的 sby 文件进行分析
        sby_file = generate_sby_file()  # 调用生成sby文件的函数
        cmd = f"sby -f {sby_file} -d {rundir} {sva_file}"
        print("run " + cmd)
        os.system(cmd)

    res_ = parse_update(itm, result_, fin.get(key, False), y['hbi_type'] == 2 and fin_data.get(k1, False))
    if key in fin:
        fin[key] = True
    if y['hbi_type'] == 2 and k1 in fin_data:
        fin_data[k1] = True
    y['Result'] = res_

    # 使用 pd.concat 替代 append
    update_map_f = pd.concat([update_map_f, pd.DataFrame([y])])

update_map_f['Result'] = update_map_f['Result'].astype(str)
update_map_f = update_map_f.astype(dtype=meta_dtypes)
update_map_f.to_csv(target_dir + "hbi_meta.txt.res", header=True, columns=list(meta_dt.columns) + ["Result"], index=False)

# 输出统计信息
print("total time: %f" % time_tt)
print("cnt:", cnt_stats)
print("time:", time_stats)
print("==============================================")
print("      %12s|%12s|%12s|" % ("(Spatial)", "(Temporal)", "Dataflow"))
print("cnt   %12d|%12d|%12d|" % (cnt_stats['struct']['spatial'], sum(cnt_stats['struct']['temporal'].values()), sum(cnt_stats['data'].values())))
print("time  %12f|%12f|%12f|" % (time_stats['struct']['spatial'], sum(time_stats['struct']['temporal'].values()), sum(time_stats['data'].values())))
print("==============================================")